"""LangGraph assembly for the complete chat pipeline."""
from functools import lru_cache

from langgraph.graph import END, START, StateGraph

from app.services.pipeline.checkpointer import make_checkpointer
from app.services.pipeline.nodes.extract_crop import extract_crop
from app.services.pipeline.nodes.filter_relevant import filter_relevant
from app.services.pipeline.nodes.generate import generate
from app.services.pipeline.nodes.normalize_language import normalize_language
from app.services.pipeline.nodes.rerank import rerank
from app.services.pipeline.nodes.retrieve import retrieve
from app.services.pipeline.nodes.rewrite_query import rewrite_query
from app.services.pipeline.nodes.understand_query import understand_query
from app.services.pipeline.state import PipelineState


def route_after_understanding(state: PipelineState) -> str:
    is_crop_query = state.get("intent") == "crop_query"
    is_supported = state.get("language") != "unsupported"
    return "extract_crop" if is_crop_query and is_supported else "generate"

def build_chat_graph():
    builder = StateGraph(PipelineState)
    
    builder.add_node("normalize_language", normalize_language)
    builder.add_node("rewrite_query", rewrite_query)
    builder.add_node("understand_query", understand_query)
    builder.add_node("extract_crop", extract_crop)
    builder.add_node("retrieve", retrieve)
    builder.add_node("rerank", rerank)
    builder.add_node("filter_relevant", filter_relevant)
    builder.add_node("generate", generate)

    builder.add_edge(START, "normalize_language")
    builder.add_edge("normalize_language", "rewrite_query")
    builder.add_edge("rewrite_query", "extract_crop")
    # builder.add_conditional_edges(
    #     "understand_query",
    #     route_after_understanding,
    #     {
    #         "extract_crop": "extract_crop",
    #         "generate": "generate",
    #     },
    # )
    builder.add_edge("extract_crop", "retrieve")
    builder.add_edge("retrieve", "rerank")
    builder.add_edge("rerank", "filter_relevant")
    builder.add_edge("filter_relevant", "generate")
    builder.add_edge("generate", END)

    return builder.compile(checkpointer=make_checkpointer())


@lru_cache
def get_chat_graph():
    return build_chat_graph()
