"""Independently testable LangGraph nodes."""
