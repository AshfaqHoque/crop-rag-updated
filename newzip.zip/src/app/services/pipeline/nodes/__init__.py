"""Independently testable LangGraph nodes."""
